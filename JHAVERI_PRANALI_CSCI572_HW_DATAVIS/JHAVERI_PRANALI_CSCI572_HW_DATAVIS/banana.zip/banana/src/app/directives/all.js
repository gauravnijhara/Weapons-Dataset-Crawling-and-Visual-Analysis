define([
  './addPanel',
  './arrayJoin',
  './dashUpload',
  './kibanaPanel',
  './ngBlur',
  './ngModelOnBlur',
  './tip',
  './confirmClick'
], function () {});